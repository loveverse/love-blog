const Koa = require("koa");
const http = require("http");
const cors = require("koa2-cors");
const bodyParser = require("koa-bodyparser");
const WebSocket = require("ws");
const { APP_PORT } = require("./config/index");
const router = require("./router/index");
const Mperson = require("./model/person");

// 创建一个Koa对象
const app = new Koa();
const server = http.createServer(app.callback());
const wss = new WebSocket.Server({ server }); // 同一端口监听不同的服务

// 解析请求体(也可以使用koa-body)
app.use(bodyParser());
// 处理跨域
app.use(cors());
app.use(router.routes());

wss.on("connection", function (ws) {
  let messageIndex = 0;
  ws.on("message", async function (data, isBinary) {
    console.log(data);
    const message = isBinary ? data : data.toString();
    if (JSON.parse(message).type !== "personData") {
      return;
    }
    const result = await Mperson.findAll();
    wss.clients.forEach((client) => {
      messageIndex++;
      client.send(JSON.stringify(result));
    });
  });
  ws.onmessage = (msg) => {
    ws.send(JSON.stringify({ isUpdate: false, message: "回复心跳包" }));
  };
  ws.onclose = () => {
    console.log("服务连接关闭");
  };
  ws.send(JSON.stringify({ isUpdate: false, message: "首次建立连接" }));
});

// const path = require('path')
// const staticFiles = require('koa-static')
// app.use(staticFiles(path.join(__dirname + '/dist/')))

server.listen(APP_PORT, () => {
  const host = server.address().address;
  const port = server.address().port;
  console.log(`服务器地址:http://${host}:${port}/findExcerpt`);
});
