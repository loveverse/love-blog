#!/bin/bash
pm2 restart ./app.js --watch